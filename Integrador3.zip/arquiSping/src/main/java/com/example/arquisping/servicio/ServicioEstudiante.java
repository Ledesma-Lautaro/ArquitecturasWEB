package com.example.arquisping.servicio;

import com.example.arquisping.modelo.Estudiante;
import com.example.arquisping.repositorios.EstudianteRepo;
import com.example.arquisping.servicio.dto.EstudianteDTO;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static java.lang.Integer.parseInt;

@Service("ServicioEstudiante")
public class ServicioEstudiante {

    private EstudianteRepo er;

    @Autowired
    public ServicioEstudiante(EstudianteRepo er){
        this.er = er;
    }


    @Transactional
    public List<EstudianteDTO> findAll() throws Exception {
        return er.findAll().stream().map(EstudianteDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public EstudianteDTO findById(Long id) throws Exception {
        return er.findById(id).map(EstudianteDTO :: new).orElse(null);
    }

    @Transactional
    public EstudianteDTO save(Estudiante entity) throws Exception {
        er.save(entity);
        return this.findById(entity.getDocumento().longValue());
    }

    @Transactional
    public EstudianteDTO update(Long id,Estudiante entity) throws Exception {
        return this.save(entity);
    }

    @Transactional
    public boolean delete(Long id) throws Exception {
        er.deleteById(id);
        return this.findById(id) != null;
    }

    @Transactional
    public List<EstudianteDTO> orderAllByName(){
        return er.orderAllByName().stream().map(EstudianteDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public EstudianteDTO getByLU(int lu){
        return er.getByLU(lu).map(EstudianteDTO::new).orElse(null);
    }

    @Transactional
    public List<EstudianteDTO> getAllByGender(String gender){
        return er.getAllByGender(gender).stream().map(EstudianteDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public List<EstudianteDTO> getEstudiantesByCarreraAndCiudad(Integer idCarrera, String ciudad){
        return er.getEstudiantesByCarreraAndCiudad(idCarrera, ciudad).stream().map(EstudianteDTO::new).collect(Collectors.toList());
    }

}
