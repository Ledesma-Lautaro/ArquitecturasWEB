package com.example.arquisping.repositorios;

import com.example.arquisping.modelo.Estudiante;
import com.example.arquisping.modelo.EstudianteCarrera;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EstudianteCarreraRepo extends  JpaRepository<EstudianteCarrera, Long>  {
}
