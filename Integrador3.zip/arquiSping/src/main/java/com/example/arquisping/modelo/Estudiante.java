package com.example.arquisping.modelo;

import com.example.arquisping.servicio.dto.EstudianteDTO;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Estudiante {
    @Id
    private Integer id;

    @Column
    private String nombre;

    @Column
    private String apellido;

    @Column
    private int edad;


    @Column
    private String ciudadResidencia;

    @Column
    private int numeroLibreta;

    @Column
    private String genero;

    @OneToMany(mappedBy = "estudiante")
    private List<EstudianteCarrera> inscripciones;

    public Estudiante(EstudianteDTO e) {
    this.id=e.getDocumento();
    this.nombre=e.getNombre();
    this.edad=e.getEdad();
    this.apellido=e.getApellido();
    this.genero=e.getGenero();
    this.ciudadResidencia=e.getCiudadResidencia();
    this.numeroLibreta=e.getNumeroLibreta();
    }

    public Estudiante() {

    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Integer getDocumento() {
        return this.id;
    }

    public void setDocumento(Integer documento) {
        this.id = documento;
    }

    public String getCiudadResidencia() {
        return ciudadResidencia;
    }

    public void setCiudadResidencia(String ciudadResidencia) {
        this.ciudadResidencia = ciudadResidencia;
    }

    public int getNumeroLibreta() {
        return numeroLibreta;
    }

    public void setNumeroLibreta(int numeroLibreta) {
        this.numeroLibreta = numeroLibreta;
    }

    public List<EstudianteCarrera> getCarreras() {
        return inscripciones;
    }

    public void setCarreras(List<EstudianteCarrera> inscripciones) {
        this.inscripciones = inscripciones;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
}


