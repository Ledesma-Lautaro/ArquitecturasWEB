package com.example.arquisping.modelo;

import com.example.arquisping.servicio.dto.CarreraDTO;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Carrera {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nombre;

    private int duracion;

    public Carrera(){

    }


    @OneToMany(mappedBy= "carrera")
    private List<EstudianteCarrera> inscripciones;

    public Carrera(CarreraDTO c) {
    this.id=c.getId();
    this.nombre=c.getNombre();
    this.duracion=c.getDuracion();
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
}

