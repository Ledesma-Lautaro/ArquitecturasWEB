package com.example.arquisping.servicio;

import com.example.arquisping.modelo.Carrera;
import com.example.arquisping.modelo.Estudiante;
import com.example.arquisping.modelo.EstudianteCarrera;
import com.example.arquisping.repositorios.CarreraRepo;
import com.example.arquisping.repositorios.EstudianteCarreraRepo;
import com.example.arquisping.repositorios.EstudianteRepo;
import com.example.arquisping.servicio.dto.CarreraDTO;
import com.example.arquisping.servicio.dto.EstudianteCarreraDTO;
import com.example.arquisping.servicio.dto.EstudianteDTO;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.lang.Integer.parseInt;
import static java.lang.Long.parseLong;

@Service
public class ServicioEstudianteCarrera{

    private EstudianteCarreraRepo ecr;
    private EstudianteRepo er;
    private CarreraRepo cr;

    @Autowired
    public ServicioEstudianteCarrera(EstudianteCarreraRepo ecr, EstudianteRepo er, CarreraRepo cr) {

        this.ecr = ecr;
        this.er=er;
        this.cr=cr;
    }


    @Transactional
    public List<EstudianteCarreraDTO> findAll() throws Exception {
        return ecr.findAll().stream().map(EstudianteCarreraDTO :: new).collect(Collectors.toList());
    }

    @Transactional
    public EstudianteCarreraDTO findById(Long id) throws Exception {
        return ecr.findById(id).map(EstudianteCarreraDTO::new).orElse(null);
    }

    @Transactional
    public EstudianteCarreraDTO save(EstudianteCarrera entity) throws Exception {
        ecr.save(entity);
        return this.findById(entity.getId_ec().longValue());
    }
    @Transactional
    public EstudianteCarreraDTO update(Long id, EstudianteCarrera entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        ecr.deleteById(id);
        return this.findById(id) != null;
    }

}
