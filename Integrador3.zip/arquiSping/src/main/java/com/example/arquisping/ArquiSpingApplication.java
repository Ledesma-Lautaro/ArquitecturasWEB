package com.example.arquisping;

import com.example.arquisping.repositorios.CarreraRepo;
import com.example.arquisping.repositorios.EstudianteCarreraRepo;
import com.example.arquisping.repositorios.EstudianteRepo;
import com.example.arquisping.servicio.ServicioCarrera;
import com.example.arquisping.servicio.ServicioEstudiante;
import com.example.arquisping.servicio.ServicioEstudianteCarrera;
import com.example.arquisping.util.CargaDeDatos;
import jakarta.annotation.PostConstruct;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

@SpringBootApplication
public class ArquiSpingApplication {

    @Autowired
    private CargaDeDatos cargaDeDatos;

    public ArquiSpingApplication() {

    }

    public static void main(String[] args) throws FileNotFoundException {
        SpringApplication.run(ArquiSpingApplication.class, args);
    }
    @PostConstruct
    public void init() throws IOException {
        cargaDeDatos.cargarDatosDesdeCSV();
    }









    }
