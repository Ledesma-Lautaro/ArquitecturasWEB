package com.example.arquisping.servicio.dto;

import com.example.arquisping.modelo.Estudiante;
import lombok.Getter;

@Getter
public class EstudianteDTO {
    private int documento;
    private String nombre;
    private String apellido;
    private int edad;
    private String ciudadResidencia;
    private int numeroLibreta;
    private String genero;

    public EstudianteDTO(int id, String nombre, String apellido, int edad, String ciudadResidencia, int numeroLibreta, String genero) {
        this.documento = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.ciudadResidencia = ciudadResidencia;
        this.numeroLibreta = numeroLibreta;
        this.genero = genero;
    }

    public EstudianteDTO(Estudiante e ){
        this.documento = e.getDocumento();
        this.nombre = e.getNombre();
        this.apellido = e.getApellido();
        this.edad = e.getEdad();
        this.ciudadResidencia = e.getCiudadResidencia();
        this.numeroLibreta = e.getNumeroLibreta();
        this.genero = e.getGenero();
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public int getDocumento() {
        return documento;
    }

    public String getCiudadResidencia() {
        return ciudadResidencia;
    }

    public int getNumeroLibreta() {
        return numeroLibreta;
    }

    public String getGenero() {
        return genero;
    }
}

