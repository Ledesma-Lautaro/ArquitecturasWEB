package com.example.arquisping.util;

import com.example.arquisping.modelo.Carrera;
import com.example.arquisping.modelo.Estudiante;
import com.example.arquisping.modelo.EstudianteCarrera;
import com.example.arquisping.repositorios.CarreraRepo;
import com.example.arquisping.repositorios.EstudianteCarreraRepo;
import com.example.arquisping.repositorios.EstudianteRepo;
import com.example.arquisping.servicio.dto.CarreraDTO;
import com.example.arquisping.servicio.dto.EstudianteDTO;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.FileReader;
import java.io.IOException;
import java.util.Optional;

import static java.lang.Integer.parseInt;
import static java.lang.Long.parseLong;

@Component
public class CargaDeDatos {

    private final EstudianteRepo er;
    private final CarreraRepo cr;

    private  final EstudianteCarreraRepo ecr;

    @Autowired
    public CargaDeDatos(EstudianteRepo er, CarreraRepo cr, EstudianteCarreraRepo ecr) {
        this.er = er;
        this.cr = cr;
        this.ecr = ecr;
    }
    public void cargarDatosDesdeCSV() throws IOException {

        CSVParser datosEstudiantes = CSVFormat.DEFAULT.withHeader().parse(new FileReader("src/main/java/com/example/arquisping/csv/estudiantes.csv"));
        CSVParser datosCarreras = CSVFormat.DEFAULT.withHeader().parse(new FileReader("src/main/java/com/example/arquisping/csv/carreras.csv"));
        CSVParser datosEstudianteCarrera = CSVFormat.DEFAULT.withHeader().parse(new FileReader("src/main/java/com/example/arquisping/csv/estudianteCarrera.csv"));

        for (CSVRecord estudiante: datosEstudiantes) {
            Estudiante e = new Estudiante();
            //DNI,nombre,apellido,edad,genero,ciudad,LU
            e.setDocumento(parseInt(estudiante.get("DNI")));
            e.setNombre(estudiante.get("nombre"));
            e.setApellido(estudiante.get("apellido"));
            e.setEdad(parseInt(estudiante.get("edad"))) ;
            e.setGenero(estudiante.get("genero"));
            e.setCiudadResidencia(estudiante.get("ciudad"));
            e.setNumeroLibreta(parseInt(estudiante.get("LU")));
            er.save(e);
        }
        for (CSVRecord carrera: datosCarreras) {
            Carrera c = new Carrera();
            //id_carrera,carrera,duracion
            c.setId(parseInt(carrera.get("id_carrera")));
            c.setNombre(carrera.get("carrera"));
            c.setDuracion(parseInt(carrera.get("duracion")));
            cr.save(c);
        }

        for (CSVRecord estudianteCarrera: datosEstudianteCarrera) {

            Optional<Estudiante> e= er.findById(parseLong(estudianteCarrera.get("id_estudiante")));
            Optional<Carrera> c= cr.findById(parseLong(estudianteCarrera.get("id_carrera")));
            EstudianteDTO es= e.map(EstudianteDTO::new).orElse(null);


            CarreraDTO car= c.map(CarreraDTO::new).orElse(null);

            if(es!=null && car!=null){
                Estudiante estudiante= new Estudiante(es);
                Carrera carrera= new Carrera(car);
                EstudianteCarrera ec = new EstudianteCarrera();
                //id,id_estudiante,id_carrera,inscripcion,graduacion,antiguedad
                ec.setId_ec(parseInt(estudianteCarrera.get("id")));
                ec.setEstudiante(estudiante);
                ec.setCarrera(carrera);
                ec.setAnioInscripcion(parseInt(estudianteCarrera.get("inscripcion")));
                ec.setAnioGraduacion(parseInt(estudianteCarrera.get("graduacion")));
                ec.setAntiguedad(parseInt(estudianteCarrera.get("antiguedad")));
                ecr.save(ec);
            }

        }

    }


}
