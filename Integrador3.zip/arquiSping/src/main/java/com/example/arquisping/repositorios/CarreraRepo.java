package com.example.arquisping.repositorios;

import com.example.arquisping.modelo.Carrera;
import com.example.arquisping.modelo.Estudiante;
import com.example.arquisping.servicio.dto.ReporteDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CarreraRepo extends JpaRepository<Carrera, Long> {

    @Query("SELECT c AS inscritos from Carrera c JOIN c.inscripciones ce GROUP BY c ORDER BY count(ce) DESC")
    public List<Carrera> getCarrerasWhitEstudiantesOrderByInscriptos();

    @Query("select NEW com.example.arquisping.servicio.dto.ReporteDTO(c.nombre,count(e),sum(case when e.anioGraduacion is not null then 1 else 0 end))"+
            "from Carrera  c join c.inscripciones e group by c.nombre, e.anioInscripcion order by c.nombre ASC, e.anioInscripcion asc ")
    public List<ReporteDTO> getReportes();

}
