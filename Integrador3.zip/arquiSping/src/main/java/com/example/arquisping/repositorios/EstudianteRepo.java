package com.example.arquisping.repositorios;

import com.example.arquisping.modelo.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EstudianteRepo extends JpaRepository<Estudiante, Long> {

@Query("SELECT e FROM Estudiante e ORDER BY e.nombre DESC")
    public List<Estudiante> orderAllByName();

@Query("SELECT e FROM Estudiante e WHERE e.numeroLibreta = :numeroLibreta")
    public Optional<Estudiante> getByLU(int numeroLibreta);

@Query("select e from Estudiante e where e.genero = :genero")
    public List<Estudiante> getAllByGender(String genero);

@Query("select e from Estudiante e join e.inscripciones ce join ce.carrera c where c.id = :id AND e.ciudadResidencia= :ciudad")
    public List<Estudiante> getEstudiantesByCarreraAndCiudad(Integer id, String ciudad);
}
