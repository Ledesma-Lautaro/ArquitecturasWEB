package com.example.arquisping.servicio.dto;

public class ReporteDTO {

    private String carrera;
    private long inscriptos;
    private long egresados;

    public ReporteDTO(String carrera,long inscriptos, long egresados) {
        this.carrera=carrera;
        this.inscriptos = inscriptos;
        this.egresados = egresados;
    }

    public long getInscriptos() {
        return inscriptos;
    }

    public long getEgresados() {
        return egresados;
    }
}
