package com.example.arquisping.servicio;

import com.example.arquisping.modelo.Carrera;
import com.example.arquisping.repositorios.CarreraRepo;
import com.example.arquisping.servicio.dto.CarreraDTO;
import com.example.arquisping.servicio.dto.ReporteDTO;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

import static java.lang.Integer.parseInt;

@Service("ServicioCarrera")
public class ServicioCarrera {

    private CarreraRepo cr;

    @Autowired
    public ServicioCarrera(CarreraRepo cr) {
        this.cr = cr;
    }

    @Transactional
    public List<CarreraDTO> findAll() throws Exception {
        return cr.findAll().stream().map(CarreraDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public CarreraDTO findById(Long id) throws Exception {
        return cr.findById(id).map(CarreraDTO::new).orElse(null);
    }

    @Transactional
    public CarreraDTO save(Carrera entity) throws Exception {
        cr.save(entity);
        return this.findById(entity.getId().longValue());
    }

    @Transactional
    public CarreraDTO update(Long id,Carrera entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        cr.deleteById(id);
        return this.findById(id) != null;
    }

    @Transactional
    public List<CarreraDTO> getCarrerasWhitEstudiantesOrderByInscriptos(){
        return cr.getCarrerasWhitEstudiantesOrderByInscriptos().stream().map(CarreraDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public List<ReporteDTO> getReportes(){
        return cr.getReportes();
    }



}
