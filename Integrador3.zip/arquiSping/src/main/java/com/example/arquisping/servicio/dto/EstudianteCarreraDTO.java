package com.example.arquisping.servicio.dto;

import com.example.arquisping.modelo.EstudianteCarrera;

public class EstudianteCarreraDTO {
    private Integer id;
    private Integer anioGraduacion;
    private Integer anioInscripcion;
    private int antiguedad;

    public EstudianteCarreraDTO(Integer id, Integer anioGraduacion, Integer anioInscripcion, int antiguedad) {
        this.id = id;
        this.anioGraduacion = anioGraduacion;
        this.anioInscripcion = anioInscripcion;
        this.antiguedad = antiguedad;
    }

    public EstudianteCarreraDTO(EstudianteCarrera ec){
        this.id = ec.getId_ec();
        this.anioGraduacion = ec.getAnioGraduacion();
        this.anioInscripcion = ec.getAnioInscripcion();
        this.antiguedad = ec.getAntiguedad();
    }

    public Integer getId() {
        return id;
    }

    public Integer getAnioGraduacion() {
        return anioGraduacion;
    }

    public Integer getAnioInscripcion() {
        return anioInscripcion;
    }

    public int getAntiguedad() {
        return antiguedad;
    }
}
