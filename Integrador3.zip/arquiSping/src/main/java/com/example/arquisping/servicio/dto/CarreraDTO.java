package com.example.arquisping.servicio.dto;

import com.example.arquisping.modelo.Carrera;

public class CarreraDTO {
    private Integer id;
    private String nombre;

    private int duracion;

    public CarreraDTO(Integer id, String nombre, int duracion) {
        this.id = id;
        this.nombre = nombre;
        this.duracion = duracion;
    }

    public CarreraDTO(Carrera c){
        this.id = c.getId();
        this.nombre = c.getNombre();
        this.duracion = c.getDuracion();
    }

    public Integer getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getDuracion() {
        return duracion;
    }
}
