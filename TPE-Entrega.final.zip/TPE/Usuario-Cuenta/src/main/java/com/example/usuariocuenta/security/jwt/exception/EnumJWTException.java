package com.example.usuariocuenta.security.jwt.exception;

public enum EnumJWTException {
    token_expired
}