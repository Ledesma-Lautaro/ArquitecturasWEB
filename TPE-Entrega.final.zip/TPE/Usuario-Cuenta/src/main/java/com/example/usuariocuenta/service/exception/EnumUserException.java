package com.example.usuariocuenta.service.exception;

public enum EnumUserException {
    invalid_account,
    invalid_authorities, already_exist
}
