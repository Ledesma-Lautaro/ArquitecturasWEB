package com.example.parada.service.exception;

public enum EnumUserException {
    invalid_account,
    invalid_authorities, already_exist
}
