package com.example.usuariocuenta.service;

import com.example.usuariocuenta.model.Usuario;
import com.example.usuariocuenta.repository.UsuarioRepositorio;
import com.example.usuariocuenta.service.dto.ParadaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.usuariocuenta.service.dto.UsuarioDTO;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UsuarioServicio {
    private UsuarioRepositorio ur;
    private RestTemplate restTemplate;

    @Autowired
    public UsuarioServicio(UsuarioRepositorio ur, RestTemplate restTemplate){
        this.ur=ur;
        this.restTemplate = restTemplate;
    }

    @Transactional
    public List<UsuarioDTO> findAll() throws Exception {
        return ur.findAll().stream().map(UsuarioDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public UsuarioDTO findById(Long id) throws Exception {
        return ur.findById(id).map(UsuarioDTO::new).orElse(null);
    }

    @Transactional
    public ResponseEntity<?> getMonopatinesCercanos(Long idUsuario) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        UsuarioDTO usuario = this.findById(idUsuario);
        if (usuario != null){
            ResponseEntity<?> response2 = restTemplate.exchange("http://localhost:8081/parada/monopatinesCercanos/" + usuario.getX() +"/" + usuario.getY(),
                    HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<ParadaDTO>>() {
                    });
            return response2;
        }
        return null;
    }

    @Transactional
    public UsuarioDTO save(Usuario entity) throws Exception {
        ur.save(entity);
        return this.findById(entity.getId());
    }

    @Transactional
    public UsuarioDTO update(Long id,Usuario entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        ur.deleteById(id);
        return this.findById(id) != null;
    }

}
