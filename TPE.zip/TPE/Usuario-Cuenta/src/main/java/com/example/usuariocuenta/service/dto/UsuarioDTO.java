package com.example.usuariocuenta.service.dto;

import com.example.usuariocuenta.model.Cuenta;
import com.example.usuariocuenta.model.Usuario;
import jakarta.persistence.*;
import lombok.Getter;

import java.io.Serializable;
import java.util.List;

@Getter
public class UsuarioDTO {

    private long id;
    private String cel;
    private String Email;
    private String nombre;
    private String apellido;
    private double x;
    private double y;

    private List<Cuenta> cuenta;

    public UsuarioDTO() {
    }

    public UsuarioDTO(Usuario usuario) {
        this.id = usuario.getId();
        this.cel = usuario.getCel();
        Email = usuario.getEmail();
        this.nombre = usuario.getNombre();
        this.apellido = usuario.getApellido();
        this.x = usuario.getX();
        this.y = usuario.getY();
        this.cuenta = usuario.getCuenta();
    }

    public UsuarioDTO(long id, String cel, String email, String nombre, String apellido, double x, double y, List<Cuenta> cuenta) {
        this.id = id;
        this.cel = cel;
        Email = email;
        this.nombre = nombre;
        this.apellido = apellido;
        this.x = x;
        this.y = y;
        this.cuenta = cuenta;
    }

    public double getX() {
        return x;
    }


    public double getY() {
        return y;
    }




    public long getId() {
        return id;
    }


    public String getCel() {
        return cel;
    }


    public String getEmail() {
        return Email;
    }


    public String getNombre() {
        return nombre;
    }


    public String getApellido() {
        return apellido;
    }


    public List<Cuenta> getCuenta() {
        return cuenta;
    }

}