package com.example.usuariocuenta.model;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.List;

@Entity
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column
    private String cel;
    @Column
    private String Email;
    @Column
    private String nombre;
    @Column
    private String apellido;



    @Column
    private double x;

    @Column
    private double y;

    @OneToMany(mappedBy = "usuarios")
    private List<Cuenta> cuenta;

    public Usuario(Usuario usuario) {
        this.id = usuario.id;
        this.cel = usuario.cel;
        Email = usuario.Email;
        this.nombre = usuario.nombre;
        this.apellido = usuario.apellido;
        this.x = usuario.x;
        this.y = usuario.y;
        this.cuenta = usuario.cuenta;
    }

    public Usuario(long id, String cel, String email, String nombre, String apellido, double x, double y, List<Cuenta> cuenta) {
        this.id = id;
        this.cel = cel;
        Email = email;
        this.nombre = nombre;
        this.apellido = apellido;
        this.x = x;
        this.y = y;
        this.cuenta = cuenta;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public Usuario(){

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCel() {
        return cel;
    }

    public void setCel(String cel) {
        this.cel = cel;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public List<Cuenta> getCuenta() {
        return cuenta;
    }

    public void setCuenta(List<Cuenta> cuenta) {
        this.cuenta = cuenta;
    }
}
