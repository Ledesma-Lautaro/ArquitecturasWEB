package com.example.monopatin.service;

import com.example.monopatin.model.Pausa;
import com.example.monopatin.repository.PausaRepositorio;
import com.example.monopatin.service.dto.PausaDTO;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PausaServicio {
    private PausaRepositorio pr;

    @Autowired
    public PausaServicio(PausaRepositorio pr){
        this.pr=pr;
    }

    @Transactional
    public PausaDTO findById(Long id) {
        return pr.findById(id).map(PausaDTO::new).orElse(null);
    }

    @Transactional
    public List<PausaDTO> findAll() throws Exception {
        return pr.findAll().stream().map(PausaDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public PausaDTO save(Pausa entity) throws Exception {
        pr.save(entity);
        return this.findById(entity.getId());
    }

    @Transactional
    public PausaDTO update(Long id, Pausa entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        pr.deleteById(id);
        return this.findById(id) != null;
    }
}
