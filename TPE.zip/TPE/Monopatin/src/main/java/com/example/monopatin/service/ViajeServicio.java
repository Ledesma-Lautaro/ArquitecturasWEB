package com.example.monopatin.service;

import com.example.monopatin.model.Viaje;
import com.example.monopatin.repository.ViajeRepositorio;
import com.example.monopatin.service.dto.ReporteKilometrajeDTO;
import com.example.monopatin.service.dto.ViajeDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ViajeServicio {
    private ViajeRepositorio rr;

    @Autowired
    public ViajeServicio(ViajeRepositorio rr) {
        this.rr = rr;
    }

    @Transactional
    public ViajeDTO findById(Long id) {
        return rr.findById(id).map(ViajeDTO::new).orElse(null);
    }

    @Transactional
    public List<ViajeDTO> findAll() throws Exception {
        return rr.findAll().stream().map(ViajeDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public ViajeDTO save(Viaje entity) throws Exception {
        rr.save(entity);
        return this.findById(entity.getId());
    }

    @Transactional
    public ViajeDTO update(Long id, Viaje entity) throws Exception {
        return this.save(entity);
    }

    @Transactional
    public boolean delete(Long id) throws Exception {
        rr.deleteById(id);
        return this.findById(id) != null;
    }

    @Transactional
    public List<ReporteKilometrajeDTO> getReporteKilometraje(long umbral, boolean conPausas){
        if(conPausas){
            return rr.getReporteKilometrajeConPausas(umbral);
        }else{
            return rr.getReporteKilometraje(umbral);
        }
    }

    @Transactional
    public Integer getFacturadoEntreMeses(int anio, int mesInicio, int mesFin) {
        return rr.getFacturadoEntreMeses(anio, mesInicio, mesFin);
    }
}
