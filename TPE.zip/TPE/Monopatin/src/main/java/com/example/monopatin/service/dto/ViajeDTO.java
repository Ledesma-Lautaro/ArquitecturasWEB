package com.example.monopatin.service.dto;

import com.example.monopatin.model.Monopatin;
import com.example.monopatin.model.Viaje;
import lombok.Getter;
import reactor.core.publisher.Mono;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
@Getter
public class ViajeDTO implements Serializable {
    private Long id;
    private Monopatin monopatinId;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private double kilometrosRecorridos;

    public ViajeDTO(Long id, Monopatin monopatin, LocalDate fechaInicio, LocalDate fechaFin, double kilometrosRecorridos) {
        this.id = id;
        this.monopatinId = monopatin;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.kilometrosRecorridos = kilometrosRecorridos;
    }

    public ViajeDTO(Viaje r) {
        this.id = r.getId();
        this.monopatinId = r.getMonopatinId();
        this.fechaInicio = r.getFechaInicio();
        this.fechaFin = r.getFechaFin();
        this.kilometrosRecorridos = r.getKilometrosRecorridos();
    }


}
