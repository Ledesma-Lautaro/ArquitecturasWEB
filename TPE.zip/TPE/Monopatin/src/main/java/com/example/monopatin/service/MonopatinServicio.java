package com.example.monopatin.service;

import com.example.monopatin.model.Monopatin;
import com.example.monopatin.repository.MonopatinRepositorio;
import com.example.monopatin.service.dto.EstadoMonopatinResponse;
import com.example.monopatin.service.dto.MonopatinDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class MonopatinServicio {
    private MonopatinRepositorio mr;

    @Autowired
    public MonopatinServicio(MonopatinRepositorio mr){
        this.mr=mr;
    }
    @Transactional
    public MonopatinDTO findById(Long id) {
        return mr.findById(id).map(MonopatinDTO::new).orElse(null);
    }

    @Transactional
    public List<MonopatinDTO> findAll() throws Exception {
        return mr.findAll().stream().map(MonopatinDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public MonopatinDTO save(Monopatin entity) throws Exception {
        mr.save(entity);
        return this.findById(entity.getId());
    }

    @Transactional
    public MonopatinDTO update(Long id, Monopatin entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        mr.deleteById(id);
        return this.findById(id) != null;
    }
    @Transactional
    public List<MonopatinDTO> getMonopatinPorAnio(Integer cantViajes, Integer anio) {
        return mr.getMonopatinPorAnio(cantViajes, anio).stream().map(MonopatinDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public EstadoMonopatinResponse getComparacionEstados() {
        return mr.getComparacionEstados();
    }
}
