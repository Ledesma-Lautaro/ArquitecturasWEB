package com.example.monopatin.service;

import com.example.monopatin.model.Precio;
import com.example.monopatin.repository.PrecioRepositorio;
import com.example.monopatin.service.dto.PrecioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PrecioServicio {
    private PrecioRepositorio pr;

    @Autowired
    public PrecioServicio(PrecioRepositorio pr) {
        this.pr = pr;
    }

    @Transactional
    public List<PrecioDTO> findAll() throws Exception {
        return pr.findAll().stream().map(PrecioDTO::new).collect(Collectors.toList());
    }
    @Transactional
    public PrecioDTO findById(Long id) throws Exception {
        return pr.findById(id).map(PrecioDTO::new).orElse(null);
    }
    @Transactional
    public PrecioDTO save(Precio p) throws Exception {
        pr.save(p);
        return this.findById(p.getId());
    }

    @Transactional
    public PrecioDTO update(Long id,Precio entity) throws Exception {
        return this.save(entity);
    }
    @Transactional
    public boolean delete(Long id) throws Exception {
        pr.deleteById(id);
        return this.findById(id) != null;
    }
}