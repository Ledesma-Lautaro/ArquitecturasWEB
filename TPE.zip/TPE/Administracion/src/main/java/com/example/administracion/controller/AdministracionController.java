package com.example.administracion.controller;

import com.example.administracion.model.Administrador;
import com.example.administracion.model.clases.Monopatin;
import com.example.administracion.model.clases.Parada;
import com.example.administracion.service.ServicioAdministracion;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/administrar")
@RequiredArgsConstructor
public class AdministracionController {
    private ServicioAdministracion sa;

    @Autowired
    public AdministracionController(ServicioAdministracion sa) {
        this.sa = sa;
    }

    @PutMapping("/monopatines/setearAMantenimiento/{idMonopatin}")
    public ResponseEntity<ResponseEntity> setearAMantenimiento (@PathVariable Long idMonopatin){
        return ResponseEntity.status(HttpStatus.OK).body(sa.settearMonopatinAMantenimiento(idMonopatin));
    }

    @PutMapping("/monopatines/finAMantenimiento/{idMonopatin}")
    public ResponseEntity<ResponseEntity> finAMantenimiento (@PathVariable Long idMonopatin){
        return ResponseEntity.status(HttpStatus.OK).body(sa.finMantenimientoMonopatin(idMonopatin));
    }

    @PostMapping("/monopatines")
    public ResponseEntity<ResponseEntity> agregarMonopatin(@RequestBody Monopatin m){
        return ResponseEntity.status(HttpStatus.OK).body(sa.agregarMonopatin(m));
    }

    @DeleteMapping("/monopatines/delete/{idMonopatin}")
    public ResponseEntity<ResponseEntity> deleteMonopatin (@PathVariable Long idMonopatin){
        return ResponseEntity.status(HttpStatus.OK).body(sa.deleteMonopatin(idMonopatin));
    }

    @PostMapping("/paradas")
    public ResponseEntity<ResponseEntity> agregarParada(@RequestBody Parada p){
        return ResponseEntity.status(HttpStatus.OK).body(sa.agregarParada(p));
    }

    @DeleteMapping("/paradas/delete/{idParada}")
    public ResponseEntity<ResponseEntity> deleteParada (@PathVariable Long idParada){
        return ResponseEntity.status(HttpStatus.OK).body(sa.deleteMonopatin(idParada));
    }



    @GetMapping("")
    public ResponseEntity<?> getAll(){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(sa.findAll());
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. Por favor intente más tarde.\"}");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOne(@PathVariable Long id){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(sa.findById(id));
        }catch (Exception e ){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\":\"Error. No se encuentra el objeto buscado" +
                    ".\"}");
        }
    }

    @PostMapping("")
    public ResponseEntity<?> save(@RequestBody Administrador entity){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(sa.save(entity));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. No se pudo ingresar, revise los campos e intente nuevamente.\"}");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id,@RequestBody Administrador entity){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(sa.update(id,entity));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. No se pudo editar, revise los campos e intente nuevamente.\"}");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id){
        try{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(sa.delete(id));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. no se pudo eliminar intente nuevamente.\"}");
        }
    }

    @GetMapping("/monopatines/reporte/kilometraje/{limite}/{incluirPausas}")
    public ResponseEntity<?> getKilometraje(@PathVariable Long limite, @PathVariable boolean incluirPausas){
        try{
            return ResponseEntity.status(HttpStatus.OK).body(sa.getKilometraje(limite, incluirPausas));
        }catch (Exception e ){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\":\"Error. no se pudo conseguir lo buscado intente nuevamente.\"}");

        }

    }

    @PutMapping("/cuentas/anular/{idCuenta}")
    public ResponseEntity<?> anularCuenta (@PathVariable Long idCuenta){
        return ResponseEntity.status(HttpStatus.OK).body(sa.anularCuenta(idCuenta));
    }

    @PutMapping("/cuentas/habilitar/{idCuenta}")
    public ResponseEntity<?> habilitarCuenta (@PathVariable Long idCuenta){
        return ResponseEntity.status(HttpStatus.OK).body(sa.habilitarCuenta(idCuenta));
    }

    @GetMapping("/monopatines/viajesPorAnio/{cantViajes}/{anio}")
    public ResponseEntity<?> getMonopatinesPorAnio(@PathVariable Integer cantViajes, @PathVariable Integer anio){
            return ResponseEntity.status(HttpStatus.OK).body(sa.getMonopatinesPorAnio(cantViajes, anio));
    }

    @GetMapping("/viajes/totalFacturado/{anio}/{mesInicio}/{mesFin}")
    public ResponseEntity<?> getTotalFacturadoEntreMeses(@PathVariable int anio, @PathVariable int mesInicio, @PathVariable int mesFin){
        return ResponseEntity.status(HttpStatus.OK).body(sa.getTotalFacturadoEntreMeses(anio, mesInicio, mesFin));
    }

    @GetMapping("/monopatines/getComparacionEstados")
    public ResponseEntity<?> getComparacionEstados(){
        return ResponseEntity.status(HttpStatus.OK).body(sa.getComparacionEstados());
    }





}
