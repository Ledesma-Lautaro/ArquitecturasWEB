package com.example.mantenimiento.service;

import com.example.mantenimiento.model.Mantenimiento;
import com.example.mantenimiento.repository.MantenimientoRepositorio;
import com.example.mantenimiento.service.dto.MantenimientoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MantenimientoServicio {
    private MantenimientoRepositorio mr;

    @Autowired
    public MantenimientoServicio(MantenimientoRepositorio mr){
        this.mr=mr;
    }

    @Transactional
    public List<MantenimientoDTO> findAll() throws Exception {
        return mr.findAll().stream().map(MantenimientoDTO::new).collect(Collectors.toList());
    }

    @Transactional
    public MantenimientoDTO save(Mantenimiento entity) throws Exception {
        Mantenimiento nuevoMantenimiento = mr.save(entity);
        return this.findById(nuevoMantenimiento.getId());
    }

    @Transactional
    public MantenimientoDTO update(Mantenimiento m) throws Exception {
        return this.save(m);
    }

    @Transactional
    public MantenimientoDTO findById(Long id) throws Exception {
        return mr.findById(id).map(MantenimientoDTO::new).orElse(null);
    }

    @Transactional
    public boolean delete(Long id) throws Exception {
        mr.deleteById(id);
        return this.findById(id) != null;
    }

    @Transactional
    public MantenimientoDTO findByIdMonopatin(Long idMonopatin) {
        return mr.findByIdMonopatin(idMonopatin).map(MantenimientoDTO::new).orElse(null);
    }
}
