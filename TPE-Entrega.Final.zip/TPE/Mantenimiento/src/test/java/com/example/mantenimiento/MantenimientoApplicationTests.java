package com.example.mantenimiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MantenimientoApplicationTests {

    @Test
    void contextLoads() {
    }

}
