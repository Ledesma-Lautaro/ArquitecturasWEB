package com.example.monopatin.model.mongo;

public class Viaje {
}
