package com.example.monopatin.model.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document
public class Monopatin {
    @Id
    private String id; // Cambiado a String para reflejar el uso de ObjectId en MongoDB
    private String numeroSerie;
    private double kilometraje;
    private boolean enMantenimiento;

    private List<Viaje> viajes;

    public Monopatin() {
    }


    public Monopatin(String id, String numeroSerie, double kilometraje, boolean enMantenimiento, List<Viaje> viajes) {
        this.id = id;
        this.numeroSerie = numeroSerie;
        this.kilometraje = kilometraje;
        this.enMantenimiento = enMantenimiento;
        this.viajes = viajes;
    }


    // Constructor, getters y setters

    // Puedes mantener tus constructores y métodos existentes según sea necesario

    public String getId() {
        return id;
    }
