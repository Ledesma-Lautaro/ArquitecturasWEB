package com.example.monopatin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonopatinApplicationTests {

    @Test
    void contextLoads() {
    }

}
