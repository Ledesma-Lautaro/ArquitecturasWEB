package com.example.administracion.repository.mongodb;

import com.example.administracion.model.mysql.Administrador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdministracionRepo extends MongoRepository<Administrador, Long> {
}
