package com.example.usuariocuenta.security;

public class DomainUserDetailsService {
}
