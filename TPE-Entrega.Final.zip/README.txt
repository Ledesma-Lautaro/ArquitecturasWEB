@Autores
Barraza Lautaro, Suarez Juan Ignacio, Ledesma Lautaro

@Swagger
http://localhost:8089/swagger-ui/
http://localhost:8085/swagger-ui/
http://localhost:8084/swagger-ui/
http://localhost:8083/swagger-ui/
http://localhost:8081/swagger-ui/

@Aclaraciones
No pudimos resolver un problema relacionado con la seguridad y el ruteo en el microservicio Administracion.
Por separado andan, pero las consultas anidadas en administracion parece que tienen un error con la propagacion del token.
En Postman, los endpoints que no andan, los marcamos con *.

